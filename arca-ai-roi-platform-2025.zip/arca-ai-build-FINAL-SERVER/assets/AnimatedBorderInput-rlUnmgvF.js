import{j as a}from"./supabase-vendor-vwXl956e.js";import{j as t}from"./index-Bcg3-yyF.js";const s=({className:r,children:e,showRadialGradient:i=!0,...n})=>a.jsx("main",{children:a.jsxs("div",{className:t("relative flex flex-col  h-[100vh] items-center justify-center bg-zinc-50 dark:bg-zinc-900  text-slate-950 transition-bg",r),...n,children:[a.jsx("div",{className:"absolute inset-0 overflow-hidden",children:a.jsx("div",{className:t(`
            [--white-gradient:repeating-linear-gradient(100deg,var(--white)_0%,var(--white)_7%,var(--transparent)_10%,var(--transparent)_12%,var(--white)_16%)]
            [--dark-gradient:repeating-linear-gradient(100deg,var(--black)_0%,var(--black)_7%,var(--transparent)_10%,var(--transparent)_12%,var(--black)_16%)]
            [--aurora:repeating-linear-gradient(100deg,var(--blue-500)_10%,var(--indigo-300)_15%,var(--blue-300)_20%,var(--violet-200)_25%,var(--blue-400)_30%)]
            [background-image:var(--white-gradient),var(--aurora)]
            dark:[background-image:var(--dark-gradient),var(--aurora)]
            [background-size:300%,_200%]
            [background-position:50%_50%,50%_50%]
            filter blur-[10px] invert dark:invert-0
            after:content-[""] after:absolute after:inset-0 after:[background-image:var(--white-gradient),var(--aurora)] 
            after:dark:[background-image:var(--dark-gradient),var(--aurora)]
            after:[background-size:200%,_100%] 
            after:animate-aurora after:[background-attachment:fixed] after:mix-blend-difference
            pointer-events-none
            absolute -inset-[10px] opacity-50 will-change-transform`,i&&"[mask-image:radial-gradient(ellipse_at_100%_0%,black_10%,var(--transparent)_70%)]")})}),e]})}),l=({children:r,className:e})=>a.jsxs("div",{className:t("relative group",e),children:[a.jsx("div",{className:"absolute -inset-0.5 bg-gradient-to-r from-blue-400 via-blue-600 to-blue-400 rounded-md blur opacity-0 group-hover:opacity-100 transition duration-300 animate-gradient-x"}),a.jsx("div",{className:"relative bg-white rounded-md",children:r})]});export{s as A,l as a};
